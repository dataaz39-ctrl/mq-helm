# IBM MQ Helm Deploy on OpenShift using Ansible Automation Platform (AAP) – Prod Ready (v3)

Repo B contains the Ansible code. It supports:
- Single Job Template via `action`: `deploy` / `dryrun` / `rollback`
- Chart source: `git` (Repo A) OR `jfrog` (Artifactory Helm repo)
- Option 1 overlays: **all values overlays in Repo B** (`values/<app>/<env>/...`)
- Prod-grade structure using `block/rescue/always`

## Best-practice checks included
### Pre-check (before deploy/rollback)
- Helm list/status for namespace/release
- OpenShift pods/svc/routes/events
- MQ Operator QueueManager CRs (best effort)

### Backup (deploy only)
- `helm get values` + `helm get manifest` + status/history

### Post-check (after deploy/rollback OR on failure)
- Helm status/history
- OpenShift routes/pods/events
- QueueManager CR status (best effort)

## QueueManager readiness gating (optional but enabled by default)
Waits for QueueManager CR to reach a "Running/Ready-like" state using `oc get queuemanager`.
- Controlled by `wait_for_qmgr_ready` (default true)
- `qmgr_cr_name` defaults to `qmgr_name`

> If your chart creates a different CR name, set `qmgr_cr_name` explicitly.

## Email notification (success/failure)
This repo can send an email using Ansible's `community.general.mail` module (SMTP).

Recommended: Use AAP **Notifications** (UI) for email. If you still want playbook-driven emails,
set:
- `enable_email_notifications=true`
- SMTP vars: `smtp_host`, `smtp_port`, `smtp_username`, `smtp_password`, `smtp_starttls`
- Email vars: `email_from`, `email_to`

Email includes:
- Pre-deploy: chart name/version/release + current helm status
- QueueManager running status (best effort)
- Post-deploy: chart name/version/release + helm status/history
- On failure: key diagnostics + artifacts folder location

Artifacts are stored under:
- `/tmp/mq-aap-artifacts/<release>/<timestamp>/...`
and published to AAP stats as `mq_artifacts_dir`.

## Execution Environment requirements
- `oc`, `helm`, `git`
- optional: `helm-diff` plugin (if enable_diff=true)
- optional: `community.general` collection for mail (recommended)
