# IBM MQ Helm Deploy on OpenShift using Ansible Tower / AAP (FINAL – Prod Ready)

## Purpose
This repository (Repo B) deploys the **mq-operator-helm** chart (Repo A) using Ansible Tower/AAP.

### Clear separation of responsibilities
| Repo | Responsibility |
|-----|---------------|
| Repo A | MQ Helm chart + platform defaults + live/recovery behavior |
| Repo B | App/env overrides, Tower logic, rollback, safety checks |

---

## Repo A (expected layout – confirmed)
```
mq-operator-helm/
├── Chart.yaml
├── templates/
├── values.yaml              # base defaults
├── values-live.yaml         # live overlay
├── values-recovery.yaml     # recovery overlay
└── README.md
```

---

## Values merge order (IMPORTANT)
Helm applies files **top → bottom** (last wins):

1. Repo A base defaults → `values.yaml`
2. Repo A role overlay → `values-live.yaml` OR `values-recovery.yaml`
3. Repo B app/env overlay → `values/<app>/<env>/values.yaml`

---

## Release naming standard
```
mq-<qmgr>-<env>
```
Example:
```
mq-qm01-dev
```

Namespace is always provided separately.

---

## Supported actions
| Action | Behavior |
|------|---------|
| deploy | upgrade/install with wait + atomic |
| dryrun | render only |
| rollback | rollback to explicit revision |

---

## Execution Environment requirements
- oc
- helm
- (optional) helm-diff plugin

---
