# mq-nativeha-crr Helm Chart

This chart deploys an IBM MQ `QueueManager` custom resource configured for **Native HA CRR** (Live/Recovery) on OpenShift using the IBM MQ Operator.

## Prerequisites
- IBM MQ Operator installed (v3.5.0+ recommended for Native HA CRR)
- Required ConfigMaps/Secrets created in the target namespace (TLS/PKI, MQSC, INI)

## Install

### Live site
```bash
helm upgrade --install mq-nativeha-crr ./mq-nativeha-crr-helm -n <live-namespace>   -f values.yaml -f values-live.yaml
```

### Recovery site
```bash
helm upgrade --install mq-nativeha-crr ./mq-nativeha-crr-helm -n <recovery-namespace>   -f values.yaml -f values-recovery.yaml
```

## Notes
- Live site **must** define `nativeHA.remotes`.
- Recovery site **must not** define `nativeHA.remotes`.
- `qm.name` should typically be the same on both sites for NativeHA.
