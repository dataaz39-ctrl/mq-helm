# Ansible Tower / AWX Promotion Workflow (DEV → TEST → PROD)

```mermaid
flowchart TD
  A[Build & Publish Helm Chart (OCI)] --> B[Deploy DEV (Tower Job Template)]
  B --> C[Smoke Tests (Tower Job Template)]
  C --> D{Approval Gate}
  D -->|Approved| E[Deploy TEST]
  E --> F[Smoke Tests]
  F --> G{Approval Gate}
  G -->|Approved| H[Deploy PROD]
  G -->|Rejected| X[Stop / Rollback Decision]
  D -->|Rejected| X
```

## Notes
- Each deploy job uses an **immutable** chart version (e.g., `1.2.3`) from your OCI registry.
- Use `atomic=true` + `wait=true` in the helm module to auto-rollback on failures.
- Store cluster credentials in Tower Credentials; do not commit kubeconfigs.
