# IBM MQ Helm Deploy on OpenShift using Ansible Tower / AAP (Prod Ready – Git or JFrog) – v2

This repo (Repo B) deploys IBM MQ Helm chart to OpenShift using a **single Job Template** driven by `action`:
- `deploy` / `dryrun` / `rollback`

It supports two chart sources:
- `chart_source=git`: clone Repo A (chart as source)
- `chart_source=jfrog`: pull chart from **JFrog Artifactory Helm repo**

## Option 1 (selected): overlays live in Repo B
Repo B owns all environment/app overlays including live/recovery:
- `values/<app>/<env>/values.yaml` (required)
- `values/<app>/<env>/values-live.yaml` (optional)
- `values/<app>/<env>/values-recovery.yaml` (optional)

Helm values merge order (last wins):
1) Repo B base: `values.yaml`
2) Repo B role overlay (live/recovery): `values-live.yaml` or `values-recovery.yaml`

## Added operational best-practice checks (v2)
Before and after deploy/rollback, the role now collects:
- Helm release list (namespace)
- Helm status/history/values/manifest for the release (if exists)
- OpenShift: pods, services, routes, events
- MQ Operator objects (best-effort): QueueManager CRs (if CRD exists)

Artifacts are stored under:
- `/tmp/mq-aap-artifacts/<release>/<timestamp>/...`
and published to AAP stats as `mq_artifacts_dir`.

## Execution Environment requirements
- `oc`, `helm`, `git`
- optional: `helm-diff` plugin (if enable_diff=true)
