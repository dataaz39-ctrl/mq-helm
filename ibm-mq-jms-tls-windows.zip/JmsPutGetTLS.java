import com.ibm.mq.jms.MQConnectionFactory;
import com.ibm.msg.client.wmq.WMQConstants;

import javax.jms.*;

public class JmsPutGetTLS {

  private static String env(String k, String def) {
    String v = System.getenv(k);
    return (v == null || v.isBlank()) ? def : v;
  }

  public static void main(String[] args) throws Exception {

    String host    = env("MQ_HOST", "IBMHAQM.exmpale.com");
    int    port    = Integer.parseInt(env("MQ_PORT", "443"));
    String channel = env("MQ_CHANNEL", "DEV.CHL");
    String qmgr    = env("MQ_QMGR", "IBMNHAQMGR");
    String queue   = env("MQ_QUEUE", "Q1");

    String cipherSuite = env("MQ_TLS_CIPHER", "TLS_RSA_WITH_AES_256_CBC_SHA256");

    MQConnectionFactory cf = new MQConnectionFactory();
    cf.setStringProperty(WMQConstants.WMQ_HOST_NAME, host);
    cf.setIntProperty(WMQConstants.WMQ_PORT, port);
    cf.setStringProperty(WMQConstants.WMQ_CHANNEL, channel);
    cf.setStringProperty(WMQConstants.WMQ_QUEUE_MANAGER, qmgr);
    cf.setIntProperty(WMQConstants.WMQ_CONNECTION_MODE, WMQConstants.WMQ_CM_CLIENT);
    cf.setStringProperty(WMQConstants.WMQ_SSL_CIPHER_SUITE, cipherSuite);

    try (Connection conn = cf.createConnection();
         Session session = conn.createSession(false, Session.AUTO_ACKNOWLEDGE)) {

      Destination dest = session.createQueue("queue:///" + queue);

      MessageProducer producer = session.createProducer(dest);
      TextMessage out = session.createTextMessage("Hello from Windows JMS over TLS!");
      producer.send(out);
      System.out.println("PUT OK: " + out.getText());

      conn.start();
      MessageConsumer consumer = session.createConsumer(dest);
      Message in = consumer.receive(5000);

      if (in == null) {
        System.out.println("GET: no message received within timeout");
      } else if (in instanceof TextMessage) {
        System.out.println("GET OK: " + ((TextMessage) in).getText());
      } else {
        System.out.println("GET OK: received non-text message");
      }
    }
  }
}