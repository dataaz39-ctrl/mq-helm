IBM MQ JMS TLS (Truststore Only) – Windows

This package contains a minimal JMS client that connects to IBM MQ over TLS
(no mutual TLS). It is intended to be run from Windows using PowerShell.

Queue Manager: IBMNHAQMGR
Channel: DEV.CHL
Route Host: IBMHAQM.exmpale.com
Port: 443

Files:
- JmsPutGetTLS.java  : Java JMS Put+Get sample
- lib/              : place MQ client jars here
- tls/trust.p12     : truststore (create separately)

Required JARs (download from Maven Central):
- com.ibm.mq.allclient-9.x.x.x.jar
- javax.jms-api-2.0.1.jar

Compile:
javac -cp "lib\com.ibm.mq.allclient-9.x.x.x.jar;lib\javax.jms-api-2.0.1.jar" JmsPutGetTLS.java

Run:
java ^
 -Djavax.net.ssl.trustStoreType=PKCS12 ^
 -Djavax.net.ssl.trustStore=trust.p12 ^
 -Djavax.net.ssl.trustStorePassword=password ^
 -Dcom.ibm.mq.cfg.useIBMCipherMappings=false ^
 -cp ".;lib\com.ibm.mq.allclient-9.x.x.x.jar;lib\javax.jms-api-2.0.1.jar" ^
 JmsPutGetTLS