import com.ibm.mq.MQException;
import com.ibm.mq.MQMessage;
import com.ibm.mq.MQQueue;
import com.ibm.mq.MQQueueManager;
import com.ibm.mq.constants.CMQC;

import java.nio.charset.StandardCharsets;
import java.util.Hashtable;

public class MqPutGetTrace {

  private static String hex(byte[] b) {
    StringBuilder sb = new StringBuilder();
    for (byte x : b) sb.append(String.format("%02X", x));
    return sb.toString();
  }

  public static void main(String[] args) throws Exception {
    String qmgr    = env("MQ_QMGR", "QM1");
    String host    = env("MQ_HOST", "mq-route.apps.ocp.example.com");
    int    port    = Integer.parseInt(env("MQ_PORT", "443"));
    String channel = env("MQ_CHANNEL", "APP.SVRCONN");
    String queue   = env("MQ_QUEUE", "DEV.QUEUE.1");

    String user    = env("MQ_USER", "ldapuser");
    String pass    = env("MQ_PASSWORD", "password");
    String cipher  = env("MQ_CIPHER", "TLS_RSA_WITH_AES_256_CBC_SHA256");
    String payload = env("MQ_PAYLOAD", "Hello from Java MQ client!");

    Hashtable<String, Object> props = new Hashtable<>();
    props.put(CMQC.HOST_NAME_PROPERTY, host);
    props.put(CMQC.PORT_PROPERTY, port);
    props.put(CMQC.CHANNEL_PROPERTY, channel);
    props.put(CMQC.TRANSPORT_PROPERTY, CMQC.TRANSPORT_MQSERIES_CLIENT);
    props.put(CMQC.SSL_CIPHER_SUITE_PROPERTY, cipher);
    props.put(CMQC.USER_ID_PROPERTY, user);
    props.put(CMQC.PASSWORD_PROPERTY, pass);

    MQQueueManager qm = null;
    MQQueue q = null;

    try {
      qm = new MQQueueManager(qmgr, props);
      int openOptions = CMQC.MQOO_INPUT_AS_Q_DEF | CMQC.MQOO_OUTPUT | CMQC.MQOO_FAIL_IF_QUIESCING;
      q = qm.accessQueue(queue, openOptions);

      MQMessage putMsg = new MQMessage();
      putMsg.format = CMQC.MQFMT_STRING;
      putMsg.characterSet = 1208;
      putMsg.writeString(payload);
      q.put(putMsg);

      MQMessage getMsg = new MQMessage();
      com.ibm.mq.MQGetMessageOptions gmo = new com.ibm.mq.MQGetMessageOptions();
      gmo.options = CMQC.MQGMO_WAIT | CMQC.MQGMO_FAIL_IF_QUIESCING;
      gmo.waitInterval = 15000;
      q.get(getMsg, gmo);

      byte[] data = new byte[getMsg.getDataLength()];
      getMsg.readFully(data);

      System.out.println("PUT/GET OK");
      System.out.println("Payload=" + new String(data, StandardCharsets.UTF_8));

    } catch (MQException mqe) {
      System.err.println("MQException CC=" + mqe.completionCode + " RC=" + mqe.reasonCode);
      throw mqe;
    } finally {
      if (q != null) q.close();
      if (qm != null) qm.disconnect();
    }
  }

  private static String env(String k, String def) {
    String v = System.getenv(k);
    return (v == null || v.isBlank()) ? def : v;
  }
}