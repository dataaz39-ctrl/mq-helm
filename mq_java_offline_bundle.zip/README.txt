OFFLINE IBM MQ JAVA CLIENT TEST (WINDOWS)

This bundle works with:
- NO admin access
- NO MQ installation
- NO internet
- TLS + LDAP supported
- PUT + GET test
- Full MQ client tracing

REQUIRED (you add):
1) com.ibm.mq.allclient.jar   (from IBM MQ client package)
2) Java runtime (portable JRE/JDK zip)
3) ca.crt (CA cert that signed QM cert)

STEPS:
1) Place com.ibm.mq.allclient.jar in this folder
2) Create truststore:
   keytool -importcert -alias mqca -file ca.crt -keystore truststore.jks -storepass changeit -noprompt
3) Set env vars:
   MQ_QMGR, MQ_HOST, MQ_PORT, MQ_CHANNEL, MQ_QUEUE, MQ_USER, MQ_PASSWORD, MQ_CIPHER
4) Compile:
   javac -cp com.ibm.mq.allclient.jar MqPutGetTrace.java
5) Run with trace:
   java -Djavax.net.ssl.trustStore=truststore.jks -Djavax.net.ssl.trustStorePassword=changeit \
        -Dcom.ibm.mq.trace.status=ON -Dcom.ibm.mq.trace.directory=trace \
        -cp ".;com.ibm.mq.allclient.jar" MqPutGetTrace

Trace logs will appear in ./trace