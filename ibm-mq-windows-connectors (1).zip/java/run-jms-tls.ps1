# run-jms-tls.ps1
# JMS (Java) connection to IBM MQ using IBM MQ Client installation jars (9.3.0.4) and TLS truststore only.

$ErrorActionPreference = "Stop"

# --- Your connection values ---
$env:MQ_HOST       = "IBMHAQM.exmpale.com"
$env:MQ_PORT       = "443"
$env:MQ_CHANNEL    = "DEV.CHL"
$env:MQ_QMGR       = "IBMNHAQMGR"
$env:MQ_QUEUE      = "Q1"

# JSSE cipher suite (because we set useIBMCipherMappings=false below)
$env:MQ_TLS_CIPHER = "TLS_RSA_WITH_AES_256_CBC_SHA256"

# --- Truststore settings (create trust.p12 or trust.jks first) ---
$TrustStorePath = ".\tls\trust.p12"
$TrustStoreType = "PKCS12"     # set to "JKS" if using trust.jks
$TrustStorePass = "password"

# --- Locate MQ allclient jar from your MQ Client install ---
# Common location:
$DefaultJar = "C:\Program Files\IBM\MQ\java\lib\com.ibm.mq.allclient.jar"

if (Test-Path $DefaultJar) {
  $MQJAR = $DefaultJar
} else {
  Write-Host "Could not find MQ jar at $DefaultJar"
  Write-Host "Searching under C:\Program Files\IBM\MQ\java\lib ..."
  $found = Get-ChildItem -Path "C:\Program Files\IBM\MQ\java\lib" -Filter "*allclient*.jar" -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
  if (-not $found) {
    throw "MQ allclient jar not found. Please set `$MQJAR manually in this script."
  }
  $MQJAR = $found.FullName
}

Write-Host "Using MQ jar: $MQJAR"
Write-Host "Using truststore: $TrustStorePath ($TrustStoreType)"

# --- Compile ---
javac -cp "$MQJAR" .\java\JmsPutGetTLS.java

# --- Run ---
java `
  -Djavax.net.ssl.trustStoreType=$TrustStoreType `
  -Djavax.net.ssl.trustStore=$TrustStorePath `
  -Djavax.net.ssl.trustStorePassword=$TrustStorePass `
  -Dcom.ibm.mq.cfg.useIBMCipherMappings=false `
  -cp ".;.\java;$MQJAR" `
  JmsPutGetTLS