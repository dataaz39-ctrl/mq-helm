# run-native-tls.ps1
# Native MQ Client test using amqsputc/amqsgetc with TLS trust-only.
# Requires IBM MQ Client installed (provides amqsputc/amqsgetc + runmqakm) and a signer cert file.

$ErrorActionPreference = "Stop"

# --- Paths (edit if you want different location) ---
$BaseDir = (Resolve-Path ".\native").Path
$TlsDir  = Join-Path $BaseDir "tls"
New-Item -ItemType Directory -Force -Path $TlsDir | Out-Null

# --- CCDT (client channel definition table) ---
$env:MQCCDTURL = "file:///" + ($BaseDir.Replace("\","/")) + "/ccdt.json"
Write-Host "MQCCDTURL=$env:MQCCDTURL"

# --- Create a CMS key database (KDB) trust store ---
# Place one of these cert files in .\native\ :
#   IBMHAQM-ca.crt  (preferred: internal CA)
#   IBMHAQM.crt     (QM leaf cert; OK for lab)
$CaCert  = Join-Path $BaseDir "IBMHAQM-ca.crt"
$QmCert  = Join-Path $BaseDir "IBMHAQM.crt"

$db = Join-Path $TlsDir "trust.kdb"
$pw = "password"

if (-not (Test-Path $db)) {
  Write-Host "Creating KDB: $db"
  runmqakm -keydb -create -db $db -pw $pw -type cms -stash
} else {
  Write-Host "KDB already exists: $db"
}

if (Test-Path $CaCert) {
  Write-Host "Adding CA cert to KDB: $CaCert"
  runmqakm -cert -add -db $db -pw $pw -label "mq-ca" -file $CaCert -format ascii -trust enable
} elseif (Test-Path $QmCert) {
  Write-Host "Adding QM leaf cert to KDB: $QmCert"
  runmqakm -cert -add -db $db -pw $pw -label "qmgr-cert" -file $QmCert -format ascii -trust enable
} else {
  throw "No certificate file found. Place IBMHAQM-ca.crt (preferred) or IBMHAQM.crt in .\native\ and rerun."
}

# MQSSLKEYR points to the KDB path WITHOUT extension
$env:MQSSLKEYR = (Join-Path $TlsDir "trust")
Write-Host "MQSSLKEYR=$env:MQSSLKEYR"

# --- Test put/get ---
$Queue = "Q1"
$Qmgr  = "IBMNHAQMGR"

Write-Host ""
Write-Host "Now running: amqsputc $Queue $Qmgr"
Write-Host "Type a message, press Enter; then press Enter on a blank line to end input."
amqsputc $Queue $Qmgr

Write-Host ""
Write-Host "Now running: amqsgetc $Queue $Qmgr"
amqsgetc $Queue $Qmgr