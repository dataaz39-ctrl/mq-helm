IBM MQ Client 9.3.0.4 – Windows Connection Pack (TLS-only)

This zip contains TWO separate ways to connect using TLS (truststore only):

1) java\   - Java JMS Put+Get program (uses IBM MQ Client installed jar)
2) native\ - Native MQ sample clients amqsputc/amqsgetc (uses CCDT + KDB trust)

Your values are already set:
- Host:   IBMHAQM.exmpale.com
- Port:   443
- Channel:DEV.CHL
- QMGR:   IBMNHAQMGR
- TLS:    trust only (no client cert)

IMPORTANT (server-side):
Your SVRCONN channel must NOT require mTLS:
  SSLCAUTH(OPTIONAL) or SSLCAUTH(NO)
If it is SSLCAUTH(REQUIRED), trust-only clients will fail.

----------------------------------------
A) Java JMS (java\run-jms-tls.ps1)
----------------------------------------
1. Create a truststore file at: .\tls\trust.p12 (PKCS12) OR .\tls\trust.jks
2. Run:
   PowerShell> .\java\run-jms-tls.ps1

----------------------------------------
B) Native MQ test (native\run-native-tls.ps1)
----------------------------------------
1. Place a signer cert file in native\:
   - native\IBMHAQM-ca.crt  (preferred: internal CA)
   OR
   - native\IBMHAQM.crt     (QM leaf cert; OK for lab)

2. Run:
   PowerShell> .\native\run-native-tls.ps1

This script:
- Uses native\ccdt.json (already built for your host/channel/qmgr/port)
- Creates native\tls\trust.kdb (CMS KDB) with a stash file
- Sets MQCCDTURL and MQSSLKEYR
- Runs amqsputc then amqsgetc