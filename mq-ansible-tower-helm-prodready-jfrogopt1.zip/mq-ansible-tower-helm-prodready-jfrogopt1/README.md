# IBM MQ Helm Deploy on OpenShift using Ansible Tower / AAP (Prod Ready – Git or JFrog)

This repo (Repo B) deploys IBM MQ Helm chart to OpenShift using a **single Job Template** driven by `action`:
- `deploy` / `dryrun` / `rollback`

It supports two chart sources:
- `chart_source=git`: clone Repo A (chart as source)
- `chart_source=jfrog`: pull chart from **JFrog Artifactory Helm repo**

## Option 1 (Selected): live/recovery overlays live in Repo B
Repo B owns all environment/app overlays including live/recovery:
- `values/<app>/<env>/values.yaml` (required)
- `values/<app>/<env>/values-live.yaml` (optional)
- `values/<app>/<env>/values-recovery.yaml` (optional)

Helm values merge order (last wins):
1) Repo B base: `values.yaml`
2) Repo B role overlay (live/recovery): `values-live.yaml` or `values-recovery.yaml`

## Release naming
`release_name = mq-<qmgr>-<env>` (derived)
Example: `mq-qm01-dev`

## Chart source usage

### A) chart_source=git
The playbook clones Repo A, then uses the local chart path.
Variables:
- `chart_git_repo`, `chart_git_branch`, `chart_git_dest`

### B) chart_source=jfrog
The playbook adds/updates a Helm repo from Artifactory and deploys by chart reference.
Variables:
- `jfrog_helm_repo_url` (e.g. https://artifactory.company.com/artifactory/helm-mq)
- `jfrog_repo_alias` (e.g. jfrog-mq)
- `chart_name` (e.g. mq-operator-helm)
- `chart_version` (optional, recommended for prod pinning)

Auth:
- Prefer AAP Credential injected as environment vars `JFROG_USER` and `JFROG_TOKEN`
- You can also pass `jfrog_user`/`jfrog_token` as extra vars (not recommended)

## Execution Environment requirements
- `oc`
- `helm`
- `git` (for chart_source=git)
- optional: `helm-diff` plugin (if enable_diff=true)

## One Job Template
Use `tower/survey.json` to drive behavior.
